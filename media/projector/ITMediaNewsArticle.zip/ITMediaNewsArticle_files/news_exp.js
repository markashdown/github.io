// URL REP
// -----------------------------------------------
var uri = document.URL;

if (uri.match('www.itm')) {ThisSite = 'itmediacojpglobal';ImgSrv = 'http:/'+'/image.itm'+'edia.co'+'.jp';}
else if (uri.match('plusd.itm')) {ThisSite = 'itmediacojpglobal';ImgSrv = 'http:/'+'/image.itm'+'edia.co'+'.jp';}
else if (uri.match('preview')) {ThisSite = 'itmediacojpglobal'+'dev';ImgSrv = '';}
else if (uri.match('bro')) {ThisSite = 'itmediacojpglobal'+'dev';ImgSrv = '';}
else {ThisSite = '';ImgSrv = '';}
if (document.URL.match(/articles\//)) {var pageDir = 'articles';} else {var pageDir = 'indexes';}

function designCnt(scID, targetURI){
var id1 = scID + '_' + pageDir;
var id2 = id1 + ' ' + targetURI;
s.prop14 = id2;
s.tl(this,'e',id1);
s_objectid = id1;
}

// SWITCH
// -----------------------------------------------
myOP = window.opera;
myN6 = document.getElementById;
myIE = document.all;
myN4 = document.layers;
if      (myOP) myBR="N6";
else if (myIE) myBR="I4";
else if (myN6) myBR="N6";
else if (myN4) myBR="N4";
else           myBR="";

function myBrowserObj(myID){
if (myBR=="N6") myRet=document.getElementById(myID).style;
else if (myBR=="I4") myRet=document.all[myID].style;
else if (myBR=="N4") myRet=document[myID];
else myRet=0;
return myRet;
}
function myDisp(myID,myVisibility){
myObj = myBrowserObj(myID);
if(myObj){myObj.display = myVisibility;}
return true;
}
function myIn(myID) {myDisp(myID,"block");}
function myOut(myID) {myDisp(myID,"none");}

// TOP10 FUNC
// -----------------------------------------------
function myBGC(myID,myBgColor){
myObj = myBrowserObj(myID);
if(myObj){myObj.background = myBgColor;}
return true;
}
function myOn(myID) {myBGC(myID,"#FC0");}
function myOff(myID) {myBGC(myID,"none");}
function Top10Write(src){
document.getElementById("rank").innerHTML = src;
}

// SWF EMBED
// -----------------------------------------------
function SwfEmbed(SwfSrc, SwfWidth, SwfHeight, SwfBgColor, SwfAlign) {

if (SwfBgColor == undefined) {ReSwfBgColor = '#FFFFFF';}
else if (SwfBgColor.length == 0) {ReSwfBgColor = '#FFFFFF';}
else if (SwfBgColor.length >= 1) {ReSwfBgColor = SwfBgColor;}
else if (SwfBgColor == 'red') {ReSwfBgColor = '#F9F1F1';}
else if (SwfBgColor == 'blue') {ReSwfBgColor = '#F1F4F6';}
else if (SwfBgColor == 'orange') {ReSwfBgColor = '#FBF5F2';}
else if (SwfBgColor == 'green') {ReSwfBgColor = '#F4F6F1';}
else if (SwfBgColor == 'left') {ReSwfBgColor = '#FFFFFF';SwfAlign = 'left';}
else if (SwfBgColor == 'right') {ReSwfBgColor = '#FFFFFF';SwfAlign = 'right';}
else if (SwfBgColor == 'center') {ReSwfBgColor = '#FFFFFF';SwfAlign = 'center';};

if (SwfAlign == undefined) {ReSwfAlign = 'none'}
else if (SwfAlign.length == 0) {ReSwfAlign = 'none'}
else if (SwfAlign == 'left') {ReSwfAlign = SwfAlign}
else if (SwfAlign == 'right') {ReSwfAlign = SwfAlign}
else if (SwfAlign == 'center') {ReSwfAlign = SwfAlign;
document.write('<div style="text-align:center;"><div style="text-align:left;width:' + SwfWidth + 'px;">');
}

document.write('<div style="width:'+ SwfWidth + 'px;float:' + ReSwfAlign + ';"><p class="flp">');
document.write('<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" width="' + SwfWidth + '" height="' + SwfHeight + '" id="flash" align="middle">');
document.write('<param name="allowScriptAccess" value="sameDomain" />');
document.write('<param name="movie" value="' + SwfSrc + '" />');
document.write('<param name="quality" value="high">');
document.write('<param name="bgcolor" value="' + ReSwfBgColor + '" />');
document.write('<embed src="' + SwfSrc + '" quality="high" bgcolor="');
document.write(ReSwfBgColor);
document.write('" width="' + SwfWidth + '" height="' + SwfHeight + '" name="flash" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer">');
document.write('</embed>');
document.write('</object>');
document.write('</p>');
document.write('<p class="flpdl"><a href="http://www.macromedia.com/shockwave/download/download.cgi?P5_Language=Japanese&Lang=Japanese&P1_Prod_Version=ShockwaveFlash&Lang=Japanese" target="_blank"><img src="');
document.write(ImgSrv);
document.write('/images0509/get_flash_player.gif');
document.write(' " alt="Get Macromedia FLASH PLAYER" width="88" height="31" border="0" align="left" style="margin-right:5px;border-width:0px!important;"></a>');
document.write('<small style="font-size:13px;line-height:125%;">���[�r�[�̉{���ɂ�<a href="http://www.macromedia.com/shockwave/download/download.cgi?P5_Language=Japanese&Lang=Japanese&P1_Prod_Version=ShockwaveFlash&Lang=Japanese" target="_blank">FLASH�v���O�C��</a>�i�o�[�W����8�ȏ�j���K�v�ł��B</small></p><br clear="all"></div>');
if (SwfAlign == 'center') {document.write('</div></div>');}
}

// SWF EMBED (NO INFO)
// -----------------------------------------------
function SwfEmbed_no(SwfSrc, SwfWidth, SwfHeight, SwfBgColor, SwfAlign) {

if (SwfBgColor == undefined) {ReSwfBgColor = '#FFFFFF';}
if (SwfAlign == undefined) {ReSwfAlign = 'none'}

document.write('<div style="width:'+ SwfWidth + 'px;float:' + ReSwfAlign + ';"><p class="flp">');
document.write('<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" width="' + SwfWidth + '" height="' + SwfHeight + '" id="flash" align="middle">');
document.write('<param name="allowScriptAccess" value="sameDomain" />');
document.write('<param name="movie" value="' + SwfSrc + '" />');
document.write('<param name="quality" value="high">');
document.write('<param name="bgcolor" value="' + ReSwfBgColor + '" />');
document.write('<embed src="' + SwfSrc + '" quality="high" bgcolor="');
document.write(ReSwfBgColor);
document.write('" width="' + SwfWidth + '" height="' + SwfHeight + '" name="flash" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer">');
document.write('</embed>');
document.write('</object>');
document.write('</p></div>');
}
